import pandas as pd


class ExperimentsLogger(object):
    pass

    def log_metric(self, name, value):
